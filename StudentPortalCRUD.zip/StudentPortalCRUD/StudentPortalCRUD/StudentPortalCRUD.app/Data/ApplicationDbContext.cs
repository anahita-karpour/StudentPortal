﻿using Microsoft.EntityFrameworkCore;
using StudentPortalCRUD.Web.Models.Entities;

namespace StudentPortalCRUD.Web.Data
{
    /// <summary>
    /// A DB context class is a class file which acts as a bridge between Entity Framework Core and the database (SQL Server)
    /// Using this class and its properties; we will be able to talk to the tables of the SQL Server from our application
    /// This class inherits from a class called DB context
    /// </summary>
    public class ApplicationDbContext : DbContext
    {
        /// <summary>
        /// Inject the class to the constructor so you are not creating a new object 
        /// </summary>
        /// <param name="options"></param>
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        //after creating an entity in the Models/Entities we will create this entity in here by creating a property which will be a DBSet
        //a DbSet represents a collection of a particualr type entity (Student)/table with the table name of Students
        //we can make use of this property Students to access and play around with the students table that has been created or will be created soon
        //in the SQl Server Database
        //this is the table that we expect to create inside the StudentPortalDb
        public DbSet<Student> Students { get; set; }
    }
}
