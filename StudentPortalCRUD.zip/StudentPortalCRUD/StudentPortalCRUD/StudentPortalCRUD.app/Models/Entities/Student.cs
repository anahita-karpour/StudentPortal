﻿namespace StudentPortalCRUD.Web.Models.Entities
{
    /// <summary>
    /// An entity (or domain model) is a class that has an identity.
    /// This is what we want to perform the CRUD operation on
    /// We are creating a model of this entity
    /// inside this entity we will have a few properties that represent this identity
    /// </summary>
    public class Student
    {
        //a unique identifier - Entity framwork Core will automatically set this ID for us
        public Guid Id { get; set; }

        //we want to capture these properties from a form using the CRUD operation
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public bool Subscribed { get; set; }
    }
}
